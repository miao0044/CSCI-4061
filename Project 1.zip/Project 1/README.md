test machine: csel-vole-01

date: 10/03/2020

name: Li Miao, Bat-Ider Ganbold, Dmitri Ivanov

x500: miao0044, ganbo011, ivano033

-----------------------------------------------------

Purpose of the program:

  The puspose of the program is to count the occurrence of each word, and print them in Reduce_ReducerTD.txt.

-----------------------------------------------------

How to compile:

  1. Open Terminal inside Template folder.
  2. run "make", then run "./mapreduce #mappers #reducers FileLocation". Where "#mappers" is the number of mappers desired, "#reducers" is the number of reducers desired, and "FileLocation" is the file destination of the input file. Put "test/T1/F1.txt" as FileLocation to test the default test file.

-----------------------------------------------------

What exactly the program does:

  It breaks the input file into chunks of data, without cutting any word into half. Each chunk contains maximum of 1024 bytes.
  nMappers amount of chindren will be spawned, each of them would get a chunk of data and call exec on mapper function. Mapper function will create a data structure to store all words occured, each word points to a ValueList with amount of 1's of the word's occurrence. Then number of nMappers .txt files would be created, with each of them writing the 1's with space in between.
  The main program would wait for all children to complete their task, then shuffle these .txt file created by mapper, using a hash function.
  Then, nReducers amount of chindren will be spawned, each of them would get some .txt files and call exec on reducer function. Reducer function will create a data structure to store all words occured, each word points to a int with amount of that word's occurrence. Then number of nReducers .txt files would be created, with each of them writing all words in data structure one by one in a newline, with the number of occurrence behind the word, with space in between.
  The main program would wait for all children to complete their task, before ending the program.

-----------------------------------------------------

Assumptions outside this document:

  1. in the header (.h) files, there are some constant variable declared to set the maximum size od datas. (For example, maximum file path is set to 50.) So if the input file is too large, it might cause overflow.
  2. if a word is extremely long, even longer than 1024 bytes, then the program would have problem breaking the chunks.
  3. There might exist some undiscovered bugs, which is unknown yet.


-----------------------------------------------------

Contribution:

  We did several discord mettings together, and wrote the codes step by step.
