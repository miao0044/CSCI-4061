#include "mapper.h"

// mapVal is the data structure for mapper function
intermediateDS* mapVal = NULL;

// combined value list corresponding to a word <1,1,1,1....>
valueList *createNewValueListNode(char *value){
	valueList *newNode = (valueList *)malloc (sizeof(valueList));
	strcpy(newNode -> value, value);
	newNode -> next = NULL;
	return newNode;
}

// insert new count to value list
valueList *insertNewValueToList(valueList *root, char *count){
	valueList *tempNode = root;
	if(root == NULL)
		return createNewValueListNode(count);
	while(tempNode -> next != NULL)
		tempNode = tempNode -> next;
	tempNode -> next = createNewValueListNode(count);
	return root;
}

// free value list
void freeValueList(valueList *root) {
	if(root == NULL) return;

	valueList *tempNode = NULL;
	while (root != NULL){
		tempNode = root;
		root = root -> next;
		free(tempNode);
	}
}

// create <word, value list>
intermediateDS *createNewInterDSNode(char *word, char *count){
	intermediateDS *newNode = (intermediateDS *)malloc (sizeof(intermediateDS));
	strcpy(newNode -> key, word);
	newNode -> value = NULL;
	newNode -> value = insertNewValueToList(newNode -> value, count);
	newNode -> next = NULL;
	return newNode;
}

// insert or update a <word, value> to intermediate DS
intermediateDS *insertPairToInterDS(intermediateDS *root, char *word, char *count){
	intermediateDS *tempNode = root;
	if(root == NULL)
		return createNewInterDSNode(word, count);
	while(tempNode -> next != NULL) {
		if(strcmp(tempNode -> key, word) == 0){
			tempNode -> value = insertNewValueToList(tempNode -> value, count);
			return root;
		}
		tempNode = tempNode -> next;

	}
	if(strcmp(tempNode -> key, word) == 0){
		tempNode -> value = insertNewValueToList(tempNode -> value, count);
	} else {
		tempNode -> next = createNewInterDSNode(word, count);
	}
	return root;
}

// free the DS after usage. Call this once you are done with the writing of DS into file
void freeInterDS(intermediateDS *root) {
	if(root == NULL) return;

	intermediateDS *tempNode = NULL;
	while (root != NULL) {
		tempNode = root;
		root = root -> next;
		freeValueList(tempNode -> value);
		free(tempNode);
	}
}

// emit the <key, value> into intermediate DS
void emit(char *key, char *value) {
  mapVal = insertPairToInterDS(mapVal, key, value);  //Author: Soumya
}

// break chunkData word by word, and pass (word, "1")
// to emit one by one
void map(char *chunkData) {
	int i = 0;
	char *buffer;
	while ((buffer = getWord(chunkData, &i)) != NULL) {
		emit(buffer, "1");
	}
}

// write intermediate data to separate word.txt files
// Each file will have only one line : word 1 1 1 1 1 ...
void writeIntermediateDS() {
	// create a intermediateDS pointer tempDS for writing the files
  intermediateDS *tempDS = mapVal;

  while (tempDS != NULL) {
		char name[MAXKEYSZ + 30];
		// MAXKEYSZ + 30 bytes ensures there would be no overflow.
		sprintf(name, "output/MapOut/Map_%d/%s.txt", mapperID, tempDS -> key);
		// set name of the .txt file, so it would be in the correct
		// map folder. with the name: word.txt

    // create a word.txt file
		int fd = open(name, O_CREAT | O_WRONLY, 0777);
		if (fd < 0) {
			printf("ERROR: Cannot open file %s\n", name);
			exit(0);
		}
		// write word into fd.
		int ret = write(fd, tempDS -> key, strlen(tempDS -> key));
		if (ret < 0) {
			printf("ERROR: Cannot write file %s\n", name);
			exit(0);
		}
    // write 1 1 1 ... into fd.
		valueList *tempV = tempDS -> value;
    while (tempV != NULL) {
			int ret = write(fd, " 1", 2);
			if (ret < 0) {
				printf("ERROR: Cannot write file %s\n", name);
				exit(0);
			}
			tempV = tempV -> next;
		}

		// close the file, and reset the string "name"
		close(fd);
		name[0] = '\0';

		//move to the next word
		tempDS = tempDS -> next;
	}
}


int main(int argc, char *argv[]) {

	// The intermediateDS *mapVal is already created
	// at top of the file.

	if (argc < 2) {
		printf("Less number of arguments.\n");
		printf("./mapper mapperID\n");
		exit(0);
	}
	// ###### DO NOT REMOVE ######
	mapperID = strtol(argv[1], NULL, 10);

	// ###### DO NOT REMOVE ######
	// create folder specifically for this mapper in output/MapOut
	// mapOutDir has the path to the folder where the outputs of
	// this mapper should be stored
	mapOutDir = createMapDir(mapperID);



	// ###### DO NOT REMOVE ######
	while(1) {
		// create an array of chunkSize=1024B and intialize all
		// elements with '\0'
		char chunkData[chunkSize + 1]; // +1 for '\0'
		memset(chunkData, '\0', chunkSize + 1);

		char *retChunk = getChunkData(mapperID);
		if(retChunk == NULL) {
			break;
		}

		strcpy(chunkData, retChunk);
		free(retChunk);

		map(chunkData);
	}

	// ###### DO NOT REMOVE ######
	writeIntermediateDS();

	// free mapVal's memory
	freeInterDS(mapVal);

	return 0;
}
