#include "reducer.h"

// reduceVal is the data structure for mapper function
finalKeyValueDS *reduceVal = NULL;

// create a key value node
finalKeyValueDS *createFinalKeyValueNode(char *word, int count){
	finalKeyValueDS *newNode = (finalKeyValueDS *)malloc (sizeof(finalKeyValueDS));
	strcpy(newNode -> key, word);
	newNode -> value = count;
	newNode -> next = NULL;
	return newNode;
}

// insert or update an key value
finalKeyValueDS *insertNewKeyValue(finalKeyValueDS *root, char *word, int count){
	finalKeyValueDS *tempNode = root;
	if(root == NULL)
		return createFinalKeyValueNode(word, count);
	while(tempNode -> next != NULL){
		if(strcmp(tempNode -> key, word) == 0){
			tempNode -> value += count;
			return root;
		}
		tempNode = tempNode -> next;
	}
	if(strcmp(tempNode -> key, word) == 0){
		tempNode -> value += count;
	} else{
		tempNode -> next = createFinalKeyValueNode(word, count);
	}
	return root;
}

// free the DS after usage. Call this once you are done with the writing of DS into file
void freeFinalDS(finalKeyValueDS *root) {
	if(root == NULL) return;

	finalKeyValueDS *tempNode = NULL;
	while (root != NULL){
		tempNode = root;
		root = root -> next;
		free(tempNode);
	}
}

// reduce function
void reduce(char *key) {
	// result will be the count of occurence of the word in key
	int result = 0;
	// buffer reads in char from key one by one
	// size of 3 is to make sure no error even for char like '\0'
	char buffer[3];
	// word will be the word in key
	char word[MAXKEYSZ];

	// open file "key" as fd
	int red = 0;
	int fd = open(key, O_RDONLY, 0777);
	if (fd < 0) {
		printf("ERROR: Cannot open file %s\n", key);
		exit(0);
	}

	// reads fd into buffer one char by one char
	while ((red = read(fd, buffer, 1)) > 0) {
		// check error
		if (red < 0) {
			printf("ERROR: Cannot read file %s\n", name);
			exit(0);
		}
		// write the word in key into word[].
		if (isalpha(buffer[0]) != 0) {
			strncat(word, &buffer[0], 1);
		}
		// for every occurence of the word, increment result
		else if (buffer[0] == '1') {
			result++;
		}
	}

	// insert word and result into reduceVal
	reduceVal = insertNewKeyValue(reduceVal, word, result);

	//reset all strings and close the file
	word[0] = '\0';
	buffer[0] = '\0';
	close(fd);
}

// write the contents of the final intermediate structure
// to output/ReduceOut/Reduce_reducerID.txt
void writeFinalDS(int reducerID){
	// name[] is the name of the reduce file
	// according to Project1.pdf, we can assume
	// the max file path to be 50 bytes.
	char name[50];
	sprintf(name, "output/ReduceOut/Reduce_%d.txt", reducerID);

	// num[] is the string to store the occurence of each word
	// the maximum number of int is 2147483647, which has 10 digits
	// Therefore, claiming num with 11 bytes would not cause overflow
	char num[11];
	// tempDS will be the pointer for reduceVal
	// for writing purpose
	finalKeyValueDS *tempDS = reduceVal;

	// create Reduce_reducerID.txt at correct location
	// and open it as fd
	int fd = open(name, O_CREAT | O_WRONLY, 0777);
	if (fd < 0) {
		printf("ERROR: Cannot open file %s\n", name);
		exit(0);
	}

	// write information in reduceVal into fd, word by word
	while (tempDS != NULL) {
		// convert the # of occurence into string
		// and store it into num[]
		sprintf(num, "%d", tempDS -> value);

		// write the word into fd
		int ret = write(fd, tempDS -> key, strlen(tempDS -> key));
		if (ret < 0) {
			printf("ERROR: Cannot write file %s\n", tempDS -> key);
			exit(0);
		}
		// write a spacebar in between
		ret = write(fd, " ", 1);
		if (ret < 0) {
			printf("ERROR: Cannot write file %s\n", name);
			exit(0);
		}
		// write the # of occurence from num[]
		ret = write(fd, num, strlen(num));
		if (ret < 0) {
			printf("ERROR: Cannot write file %s\n", name);
			exit(0);
		}
		// write a newline
		if (tempDS -> next != NULL) {
			ret = write(fd, "\n", 1);
			if (ret < 0) {
				printf("ERROR: Cannot write file %s\n", name);
				exit(0);
			}
		}
		// move onto the next word, and reset all strings
		tempDS = tempDS -> next;
		num[0] = '\0';
		name[0] = '\0';
	}
	//close the file fd
	close(fd);
}

int main(int argc, char *argv[]) {

	if(argc < 2){
		printf("Less number of arguments.\n");
		printf("./reducer reducerID");
	}

	// ###### DO NOT REMOVE ######
	// initialize
	int reducerID = strtol(argv[1], NULL, 10);

	// ###### DO NOT REMOVE ######
	// master will continuously send the word.txt files
	// alloted to the reducer
	char key[MAXKEYSZ];
	while(getInterData(key, reducerID))
		reduce(key);

	// You may write this logic. You can somehow store the
	// <key, value> count and write to Reduce_reducerID.txt file
	// So you may delete this function and add your logic
	writeFinalDS(reducerID);

	// free reduceVal's memory
	freeFinalDS(reduceVal);

	return 0;
}
