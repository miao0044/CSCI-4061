#include "utils.h"

#define PERM 0666

// recieve next tagged chunk from the queue
char *getChunkData(int mapperID) {

    // initializing key to access the same msgid as other programs
    key_t key;
    int msgid;
    struct msgBuffer msg;
    key = ftok (".", 5226197);

    // open message queue
    if ((msgid = msgget(key, PERM)) < 0) {
        printf("msg queue opening error");
        exit(1);
    }

    // recieve chunk from the master
    if(msgrcv(msgid, &msg, MSGSIZE, mapperID, 0) < 0) {
        printf("getChunkData receive error");
        exit(0);
    }

    // if END message received, send ACK and return NULL
    if (strcmp(msg.msgText, "END") == 0) {
      msg.msgType = 100000 + mapperID;
      sprintf(msg.msgText, "ACK");

      if ((msgsnd(msgid, &msg, MSGSIZE, 0)) < 0) {
          printf("mapper getChunkData send ack error");
          exit(0);
      }
      return NULL;
    }
    // if not, return received string
    else{
        char *retChunk = (char *)malloc(sizeof(char) * (strlen(msg.msgText) + 1));
        strcpy(retChunk, msg.msgText);
        return retChunk;
    }
}


// sends chunks of size 1024 to the mappers in RR fashion
void sendChunkData(char *inputFile, int nMappers) {

    // initializing key to access the same msgid as other programs
    key_t key;
    int msgid;
    struct msgBuffer msg;
    key = ftok(".", 5226197);

    // open message queue
    if ((msgid = msgget(key, PERM | IPC_CREAT)) < 0) {
        printf("msg queue opening error");
        exit(1);
    }

    // open the input file
    FILE *fp = fopen(inputFile, "r");
    if (fp == NULL) {
        printf("file open error");
        exit(1);
    }

    int mapperId = 0;

    while(1) {
        // read in chunksize bytes, once at a time
        size_t num = fread(msg.msgText, 1, chunkSize + 1, fp);
        if(num == 0) {
            break;
        }

        int actualCount = num;
        if(num == chunkSize + 1) {
            // check word boundary
            int k = chunkSize - 1;
            if(validChar(msg.msgText[chunkSize])) {
                while(validChar(msg.msgText[k])) {
                    k--;
                }
            }

            actualCount = k + 1;
            int left = chunkSize + 1 - actualCount;

            // backtrack, not include the word in boundary
            fseek(fp, -left, SEEK_CUR);
        }

        msg.msgText[actualCount] = '\0';
        mapperId++;
        msg.msgType = mapperId;

        // send message to mapper
        if ((msgsnd(msgid, &msg, MSGSIZE, 0)) < 0) {
            printf("msgsnd error in sendChunkData send");
            exit(0);
        }

        mapperId = mapperId % nMappers;
        if (num < chunkSize + 1) {
            break;
        }
    }

    // send end message to each mapper
    for (mapperId = 1; mapperId <= nMappers; ++mapperId)
    {
        msg.msgType = mapperId;
        sprintf(msg.msgText, "END");
        if ((msgsnd(msgid, &msg, MSGSIZE, 0)) < 0) {
            printf("msgsnd error in sender end to mapper");
            exit(0);
        }
    }

    // receive ACK from mapper
    for (mapperId = 1; mapperId <= nMappers; ++mapperId) {
        if(msgrcv(msgid, &msg, MSGSIZE, 100000 + mapperId, 0) < 0) {
            printf("msgrcv error in reciever");
            exit(0);
        }
    }
    // destory queue
    msgctl(msgid, IPC_RMID, 0);
}


// hash function to divide the list of word.txt files across reducers
//http://www.cse.yorku.ca/~oz/hash.html
int hashFunction(char* key, int reducers){
    unsigned long hash = 0;
    int c;

    while ((c = *key++)!='\0')
        hash = c + (hash << 6) + (hash << 16) - hash;

    return (hash % reducers);
}


// retrieve the file path for words and compute the total amount
int getInterData(char *key, int reducerID) {

    // initializing key to access the same msgid as other programs
    key_t mykey;
    int msgid;
    struct msgBuffer msg;
    mykey = ftok (".", 5226197);

    // open message queue
    if ((msgid = msgget(mykey, PERM)) < 0) {
        printf("msg queue opening error");
        exit(1);
    }

    // recieve chunk from the master
    if(msgrcv(msgid, &msg, MSGSIZE, reducerID, 0) < 0) {
        printf("getInterData receive error");
        exit(0);
    }

    // check whether END message,
    if (strcmp(msg.msgText, "END") == 0) {
      msg.msgType = 100000 + reducerID;
      sprintf(msg.msgText, "ACK");

      // send ack
      if ((msgsnd(msgid, &msg, MSGSIZE, 0)) < 0) {
          printf("reducer getInterData send ack error");
          exit(0);
      }
        return 0;

    } else{
        // store received file path
        sprintf(key, "%s", msg.msgText);
        return 1;
    }
}



// check whether ".txt" file
int isTxt(const char* fn) {

    int len = strlen(fn);
    if(len < 4) {
        return 0;
    }

    if(fn[len - 4] == '.' &&  fn[len - 3] == 't' && fn[len - 2] == 'x' && fn[len - 1] == 't' ) {
        return 1;
    } else{
        return 0;
    }
}


// send word files from mappers to reducers
// reducerID decided by a hash function
void shuffle(int nMappers, int nReducers) {

    // initializing key to access the same msgid as other programs
    key_t key;
    int msgid;
    struct msgBuffer msg;
    key = ftok(".", 5226197);

    //open message queue
    if ((msgid = msgget(key, PERM | IPC_CREAT)) < 0) {
        printf("msg queue opening error");
        exit(1);
    }

    int i,j;
    int reducerID;
    //  buffer for path name of mapper folders
    char mapdir[51];

    struct dirent* entry;
    for (i = 1; i <= nMappers; i++) {
        sprintf(mapdir, "output/MapOut/Map_%d", i); // constructing file path towards map_i th file
        DIR* mapperdir = opendir(mapdir);			//opening the map_i th dir

        while((entry = readdir(mapperdir)) != NULL) {		//inside map_i
            if (!strcmp(entry->d_name, ".") || !strcmp(entry -> d_name, "..")) //error checking
                continue;
            // if its a directory its an unexpected error
            if(entry->d_type == DT_DIR) {
                printf("unexpected filetype (This should be a file type not a dir)");
            }
            // if its a regular file then it must be a wordfile
            else if (entry->d_type ==DT_REG || isTxt(entry->d_name)) {

                // creating a buffer for wordfilepath
                char wordFilePath[strlen(mapdir)+strlen(entry->d_name)+2];
                // putting word filepath to the buffer wordFilePath
                sprintf(wordFilePath,"output/MapOut/Map_%d/%s",i,entry->d_name);
                // select reducer using a hash function
                reducerID = hashFunction(entry -> d_name,nReducers)+1;
                // memset(msg.msgText, '\0', MSGSIZE);
                strcpy(msg.msgText, wordFilePath);
                msg.msgType = reducerID;

                while(1) {

                	// send file path to reducer
                    if ((msgsnd(msgid, &msg, MSGSIZE, 0) )< 0) {
                        printf("shuffle msgsnd error to reducer");
                        perror("shuffle msgsnd");
                        sleep(1);
                    }else{
                        break;
                    }
                }
            }
        }
        closedir(mapperdir);						//closing map_i th dir
    }

    int reduceId;
    // send end message to each reducer
    for (reduceId = 1; reduceId <= nReducers; ++reduceId)
    {
        msg.msgType = reduceId;
        sprintf(msg.msgText, "END");
        if ((msgsnd(msgid, &msg, MSGSIZE, 0)) < 0) {
            printf("shuffle msgsnd error send end to reducer");
            exit(0);
        }
    }

    // receive ACK from each reducer
    for (reduceId = 1; reduceId <= nReducers; ++reduceId)
    {
        if(msgrcv(msgid, &msg, MSGSIZE, 100000 + reduceId, 0) < 0) {
            printf("shuffle msgrcv error in reciever\n");
            exit(0);
        }
    }

    // destory queue
    msgctl(msgid, IPC_RMID, 0);
}


// check if the character is valid for a word
int validChar(char c){
    return (tolower(c) >= 'a' && tolower(c) <='z') ||
    (c >= '0' && c <= '9');
}


char *getWord(char *chunk, int *i){
    char *buffer = (char *)malloc(sizeof(char) * chunkSize);
    memset(buffer, '\0', chunkSize);
    int j = 0;
    while((*i) < strlen(chunk)) {
        // read a single word at a time from chunk
        if (chunk[(*i)] == '\n' || chunk[(*i)] == ' ' || !validChar(chunk[(*i)]) || chunk[(*i)] == 0x0) {
            buffer[j] = '\0';
            if(strlen(buffer) > 0){
                (*i)++;
                return buffer;
            }
            j = 0;
            (*i)++;
            continue;
        }
        buffer[j] = chunk[(*i)];
        j++;
        (*i)++;
    }
    if(strlen(buffer) > 0)
        return buffer;
    return NULL;
}


void createOutputDir(){
    mkdir("output", ACCESSPERMS);
    mkdir("output/MapOut", ACCESSPERMS);
    mkdir("output/ReduceOut", ACCESSPERMS);
}


char *createMapDir(int mapperID){
    char *dirName = (char *) malloc(sizeof(char) * 100);
    memset(dirName, '\0', 100);
    sprintf(dirName, "output/MapOut/Map_%d", mapperID);
    mkdir(dirName, ACCESSPERMS);
    return dirName;
}


void removeOutputDir(){
    pid_t pid = fork();
    if(pid == 0){
        char *argv[] = {"rm", "-rf", "output", NULL};
        if (execvp(*argv, argv) < 0) {
            printf("ERROR: exec failed\n");
            exit(1);
        }
        exit(0);
    } else{
        wait(NULL);
    }
}


void bookeepingCode(){
    removeOutputDir();
    sleep(1);
    createOutputDir();
}
