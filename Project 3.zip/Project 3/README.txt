1. Group Information
  GroupID: 117
  Member Name: Dmitri Ivanov, Li Miao, Bat-Ider Ganbold
  X500: ivano033, miao0044, ganbo011

2. How To Compile And Run
  compile:
    make
  command usage:
    usage: ./web_server port path num_dispatcher num_workers dynamic_flag queue_length cache_size
  First run server:
    run basic server:
      ./web_server 9000 testing 10 10 0 5 0
    run server with dynamic woker:
      ./web_server 9000 testing 10 10 1 5 0
    run server with cache enable(just pass no zero value at cache_size argument):
      ./web_server 9000 testing 10 10 0 5 20
    run server with dynamic woker and cache enable:
      ./web_server 9000 testing 10 10 1 5 20
  Then run client:
    run client:
      single command:
        wget http://127.0.0.1:9000/text/html/0.html
        wget http://127.0.0.1:9000/text/html/999.html
      or if you have testing directory
        wget -i path-to-testing/urls
        wget -i path-to-testing/bigurls
      concurrent version:
        cat path-to-testing/urls | xargs -n 10 -P 10 wget
        cat path-to-testing/bigurls | xargs -n 10 -P 10 wget

3. How Program works
  The important point of program is the request queue.
  Dispatch thread receive request and put into the queue.
  Worker thread get request from the queue.
  Because there are multiple thread to manipulate this queue, a synchronization mechanism using pthread_mutex are used.
  Above methioned part are at function "addRequestQueue" and "getRequestQueue", you can check them for details.

4. Extra Credit Implements:
  Both

5. Policy Of Dynamically Changing Worker Thread Pool Size
Keep tracking the occupied ratio of request queue, and do the woker thread adding and removing as below. The specified num of workers to be added will be modified at actual implementation.
  ratio: < 10%, -1 worker;
  60%< ratio<80%: +1 worker;
  80%< ratio: +2 worker

6. Cacheing Mechanism
  FIFO policy

7. Team Member Contribution
  We did several discord meetings together, and wrote the codes step by step.

8. Please check "server.c" for code comments.
