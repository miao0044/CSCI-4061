#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>
#include "util.h"
#include <stdbool.h>
#include <unistd.h>
#include <signal.h>
#include <dirent.h>

#define MAX_THREADS 100
#define MAX_QUEUE_LEN 100
#define MAX_CE 100
#define INVALID -1
#define BUFF_SIZE 1024

void * worker(void *arg);  // used by dynamic worker thread pool

// structs:
typedef struct request_queue {
  int fd;
  char *request;
} request_t;

typedef struct cache_entry {
    int len;
    char *request;
    char *content;
} cache_entry_t;

// global variable to be easily accessed
int port, num_dispatch, num_workers, dynamic_flag, qlen, cache_entries;
char *root_path;
bool stop = false;
// woker and dispather thread_pool
request_t **queue = NULL;
char *file_not_exist_str = "file_not_exist";

/* ******************** Log Part ***************************************************/
FILE *log_file;
pthread_mutex_t log_mutex = PTHREAD_MUTEX_INITIALIZER;

// Function to log into file and stdout, normal version
void logNormal(long int threadId, int reqNum, int fd, char *req_str, int bytes, bool cache_hit) {
  char log_buffer[BUFF_SIZE];
  const char *hit_miss_str = cache_hit ? "Hit" : "Miss";
  if (cache_entries > 0) {
    snprintf(log_buffer, BUFF_SIZE, "[%ld][%d][%d][%s][%d][%s]\n",
              threadId, reqNum, fd, req_str, bytes, hit_miss_str);
  } else {
    snprintf(log_buffer, BUFF_SIZE, "[%ld][%d][%d][%s][%d]\n",
              threadId, reqNum, fd, req_str, bytes);
  }
  pthread_mutex_lock(&log_mutex);
  printf("%s", log_buffer);
  fwrite(log_buffer, sizeof(char), strlen(log_buffer), log_file);
  pthread_mutex_unlock(&log_mutex);
}

// Function to log into file and stdout, error version.
void logError(long int threadId, int reqNum, int fd, char *req_str, char *error, bool cache_hit) {
  char log_buffer[BUFF_SIZE];
  const char *hit_miss_str = cache_hit ? "Hit" : "Miss";
  if (cache_entries > 0) {
    snprintf(log_buffer, BUFF_SIZE, "[%ld][%d][%d][%s][%s][%s]\n",
              threadId, reqNum, fd, req_str, error, hit_miss_str);
  } else {
    snprintf(log_buffer, BUFF_SIZE, "[%ld][%d][%d][%s][%s]\n",
              threadId, reqNum, fd, req_str, error);
  }
  pthread_mutex_lock(&log_mutex);
  printf("%s", log_buffer);
  fwrite(log_buffer, sizeof(char), strlen(log_buffer), log_file);
  pthread_mutex_unlock(&log_mutex);
}

// Function to log into file and stdout, dyanmic woker version.
void logDynamicWoker(bool create, int num, double ratio) {
  ratio *= 100;
  char log_buffer[BUFF_SIZE];
  if (create) {
    snprintf(log_buffer, BUFF_SIZE, "Created %d worker threads because %.2f%% request queue are occupied\n", num, ratio);
  } else {
    snprintf(log_buffer, BUFF_SIZE, "Removed %d worker threads because %.2f%% request queue are occupied\n", num, ratio);
  }
  pthread_mutex_lock(&log_mutex);
  printf("%s", log_buffer);
  fwrite(log_buffer, sizeof(char), strlen(log_buffer), log_file);
  pthread_mutex_unlock(&log_mutex);
}

/* ******************** Queue Adding/Getting Action ********** ***********************/
pthread_mutex_t queue_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t queue_cond = PTHREAD_COND_INITIALIZER;
int add_queue_idx = 0, get_queue_idx = 0;

// add request into queue
void addRequestQueue(request_t *request) {
  pthread_mutex_lock(&queue_mutex);
  int idx = add_queue_idx%qlen;
  if (queue[idx] != NULL) {
    // queue already full, replace queue element
    // ! situation may considering when to increase the woker thread num
    return_error(queue[idx]->fd, "request queue full");
    free(queue[idx]->request);
    free(queue[idx]);
  }
  queue[idx] = request;
  ++add_queue_idx;
  pthread_cond_signal(&queue_cond);
  pthread_mutex_unlock(&queue_mutex);
}

// get request from queue
// return NULL means queue is empty
request_t* getRequestQueue() {
  request_t *request = NULL;
  pthread_mutex_lock(&queue_mutex);
  // only fetch elem when queue is not empty
  if (get_queue_idx == add_queue_idx) {
    pthread_cond_wait(&queue_cond, &queue_mutex);
  }
  if (get_queue_idx < add_queue_idx) {
    int idx = get_queue_idx % qlen;
    request = queue[idx];
    queue[idx] = NULL;
    ++get_queue_idx;
  }
  pthread_mutex_unlock(&queue_mutex);
  return request;
}

/**********************************************************************************/

/* ******************** Dynamic Pool Code  [Extra Credit A] **********************/
// current worker num and expected num
// worker_num_cur should be close to worker_num_except
pthread_mutex_t worker_num_mutex = PTHREAD_MUTEX_INITIALIZER;
int worker_num_except = 1, worker_num_cur = 1;
const int woker_num_level[3] = {-1, 1, 2};
// Extra Credit: This function implements the policy to change the worker thread pool dynamically
// depending on the ratio of request queue occupied status
void * dynamic_pool_size_update(void *arg) {
  while (!stop) {
    usleep(1000);  // sleep 1ms as monitored interval
    pthread_mutex_lock(&queue_mutex);
    double ratio = (add_queue_idx-get_queue_idx)/(double)qlen;
    pthread_mutex_unlock(&queue_mutex);
    pthread_mutex_lock(&worker_num_mutex);
    // printf("ratio: %.2f\n", ratio);
    if (ratio < 0.1) {
      // remove a worker
      if (worker_num_except == 1) {
        pthread_mutex_unlock(&worker_num_mutex);
        continue;
      }
      worker_num_except += woker_num_level[0];
      logDynamicWoker(false, -woker_num_level[0], ratio);
    } else if (ratio > 0.6 && ratio < 0.8) {
      // add small number of worker
      int except = worker_num_except + woker_num_level[1];
      if (except <= MAX_THREADS) {
        worker_num_except = except;
        logDynamicWoker(true, woker_num_level[1], ratio);
      }
    } else if (ratio > 0.8) {
      // add large number of worker
      int except = worker_num_except + woker_num_level[2];
      if (except <= MAX_THREADS) {
        worker_num_except = except;
        // printf("add_queue_idx:%d, get_queue_idx:%d\n", add_queue_idx, get_queue_idx);
        logDynamicWoker(true, woker_num_level[2], ratio);
      }
    }
    for (; worker_num_cur <= worker_num_except; ++worker_num_cur) {
      pthread_t t;
      int worker_tid = worker_num_cur - 1;
      pthread_create(&t, NULL, worker, &worker_tid);
    }
    --worker_num_cur;
    pthread_mutex_unlock(&worker_num_mutex);
  }
  return NULL;
}
/**********************************************************************************/

/* ************************ Cache Code [Extra Credit B] **************************/
typedef struct CacheEntry {
  char *request;
  char *data;
  int memory_size;
} CacheEntry;
CacheEntry *cache = NULL;
pthread_mutex_t cache_lock = PTHREAD_MUTEX_INITIALIZER;
int cache_add_idx = 0;

// Function to check whether the given request is present in cache
int getCacheIndex(char *request) {
  if (cache_entries <= 0) return cache_entries;
  // return the index if the request is present in the cache
  pthread_mutex_lock(&cache_lock);
  int idx = 0;
  for (; idx < cache_entries; ++idx) {
    if (cache[idx].request != NULL &&
        strcmp(request, cache[idx].request) == 0) {
      break;
    }
  }
  pthread_mutex_unlock(&cache_lock);
  return idx;
}

// Function to add the request and its file content into the cache
void addIntoCache(char *mybuf, char *memory , int memory_size) {
  // It should add the request at an index according to the cache replacement policy
  // Make sure to allocate/free memory when adding or replacing cache entries
  if (cache_entries <= 0) return;
  pthread_mutex_lock(&cache_lock);
  int idx = cache_add_idx % cache_entries;
  if (cache[idx].request != NULL) {
    // FIFO cache replacement
    free(cache[idx].request);
    if (cache[idx].data != NULL) {
      free(cache[idx].data);
    }
  }
  cache[idx].request = mybuf;
  cache[idx].data = memory;
  cache[idx].memory_size = memory_size;
  ++cache_add_idx;
  pthread_mutex_unlock(&cache_lock);
}

// clear the memory allocated to the cache
void deleteCache() {
  if (cache_entries <= 0) return;
  // De-allocate/free the cache memory
  pthread_mutex_lock(&cache_lock);
  for (int i = 0; i < cache_entries; ++i) {
    if (cache[i].request != NULL) {
      free(cache[i].request);
      free(cache[i].data);
    }
  }
  pthread_mutex_unlock(&cache_lock);
}

// Function to initialize the cache
void initCache() {
  if (cache_entries <= 0) return;
  // Allocating memory and initializing the cache array
  cache = malloc(sizeof(CacheEntry)*cache_entries);
  for (int i = 0; i < cache_entries; ++i) {
    cache[i].request = NULL;
    cache[i].data = NULL;
  }
}

/**********************************************************************************/

/* ************************************ Utilities ********************************/
char *content_type[4] = {"text/html", "image/jpeg", "image/gif", "text/plain"};
// Function to get the content type from the request
int getContentType(char * filepath) {
  // Should return the content type based on the file type in the request
  // (See Section 5 in Project description for more details)
  int start = strlen(filepath) - 1- 3;
  if (strncmp(filepath+start, "tml", 3) == 0) {
    return 0;
  } else if (strncmp(filepath+start, "jpg", 3) == 0) {
    return 1;
  } else if (strncmp(filepath+start, "gif", 3) == 0) {
    return 2;
  }
  return 3;
}

// Function to open and read the file from the disk into the memory
// input filepath
// return NULL means no such file, or actual content.
// read_bytes record how many bytes read from this file
// need free the returned data after response
char *readFromDisk(char *filepath, int *read_bytes) {
  // Open and read the contents of file given the request
  FILE *file = fopen(&filepath[1], "r");
  if (file) {
    fseek(file, 0L, SEEK_END);
    *read_bytes = ftell(file);
    fseek(file, 0L, SEEK_SET);
    char *data = malloc(sizeof(char)*(*read_bytes+1));
    fread(data, 1, *read_bytes, file);
    fclose(file);
    return data;
  } else {
    return NULL;
  }
}

/**********************************************************************************/
pthread_mutex_t con_mutex = PTHREAD_MUTEX_INITIALIZER;
// Function to receive the request from the client and add to the queue
void * dispatch(void *arg) {
  pthread_detach(pthread_self());
  while (!stop) {
    // Accept client connection
    pthread_mutex_lock(&con_mutex);
    int fd = accept_connection();
    pthread_mutex_unlock(&con_mutex);
    if (fd < 0) continue;
    // Get request from the client
    request_t *request = malloc(sizeof(request_t));
    request->fd = fd;
    request->request = malloc(sizeof(char)*BUFF_SIZE);
    if (get_request(fd, request->request) != 0) {
      free(request->request);
      free(request);
      continue;
    }
    // Add the request into the queue
    addRequestQueue(request);
  }
  return NULL;
}

/**********************************************************************************/

// Function to retrieve the request from the queue, process it and then return a result to the client
void * worker(void *arg) {
  int threadId = *(int*)arg;
  pthread_detach(pthread_self());
  int reqNum = 0;
  while (!stop) {
    if (dynamic_flag) {
      // delete worker when there are not too much request
      pthread_mutex_lock(&worker_num_mutex);
      if (worker_num_cur > worker_num_except) {
        --worker_num_cur;
        printf("thread %d exit.\n", threadId);
        pthread_mutex_unlock(&worker_num_mutex);
        break;
      }
      pthread_mutex_unlock(&worker_num_mutex);
    }
    // Get the request from the queue
    // printf("Before get request\n");
    request_t *request = getRequestQueue();
    // printf("After get request\n");
    // if (request == NULL) {
    //   printf("thread %d get NULL request\n", threadId);
    // }
    if (request == NULL) continue;
    ++reqNum;
    // Get the data from the disk or the cache (extra credit B)
    bool cache_hit = true;
    int cache_idx = getCacheIndex(request->request);
    int read_bytes = 0;
    char *data = NULL, *type = NULL;
    if (cache_idx < cache_entries) {
      // cache hit
      data = cache[cache_idx].data;
      read_bytes = cache[cache_idx].memory_size;
    } else {
      // cache miss
      data = readFromDisk(request->request, &read_bytes);
      char *mybuf = malloc(sizeof(char)*(strlen(request->request)+1));
      strcpy(mybuf, request->request);
      addIntoCache(mybuf, data, read_bytes);
      cache_hit = false;
    }
    bool file_exist = true;
    if (data == NULL) {
      file_exist = false;
    } else {
      type = content_type[getContentType(request->request)];
    }
    // Log the request into the file and terminal
    // return the result
    if (!file_exist) {
      return_error(request->fd, "file not exist");
      logError(threadId, reqNum, request->fd, request->request, file_not_exist_str, cache_hit);
    } else {
      return_result(request->fd, type, data, read_bytes);
      logNormal(threadId, reqNum, request->fd, request->request, read_bytes, cache_hit);
    }
    free(request);
  }
  return NULL;
}

/**********************************************************************************/
// Function to assign command arguments
void getArgs(char **argv) {
  port = atoi(argv[1]);
  root_path = argv[2];
  num_dispatch = atoi(argv[3]);
  num_workers = atoi(argv[4]);
  dynamic_flag = atoi(argv[5]);
  qlen = atoi(argv[6]);
  cache_entries = atoi(argv[7]);
}

// Function to check the command arguments
bool checkArgs() {
  bool is_pass = true;
  if (port < 1025 || port > 65535) {
    fprintf(stderr, "port '%d' can only be in the range of 1025-65535.\n", port);
    is_pass = false;
  }
  // check whether path exists
  DIR *root_dir = opendir(root_path);
  if (root_dir) {
    closedir(root_dir);
  } else if (ENOENT == errno) {
    fprintf(stderr, "path '%s' not exist.\n", root_path);
    is_pass = false;
  } else {
    fprintf(stderr, "error opening path '%s'\n", root_path);
  }
  if (port < 1025 || port > 65535) {
    fprintf(stderr, "port '%d' can only be in the range of 1025-65535.\n", port);
    is_pass = false;
  }
  if (num_dispatch <= 0 || num_dispatch > MAX_THREADS) {
    fprintf(stderr, "num_dispatch '%d' can only be in the range of 1-100.\n", num_dispatch);
    is_pass = false;
  }
  if (num_workers <= 0 || num_workers > MAX_THREADS) {
    fprintf(stderr, "num_workers '%d' can only be in the range of 1-100.\n", num_workers);
    is_pass = false;
  }
  if (dynamic_flag != 0 && dynamic_flag != 1) {
    fprintf(stderr, "dynamic_flag '%d' can only be 0/1.\n", dynamic_flag);
    is_pass = false;
  }
  if (qlen <= 0 || qlen > MAX_QUEUE_LEN) {
    fprintf(stderr, "qlen '%d' can only be in the range of 1-100.\n", qlen);
    is_pass = false;
  }
  if (cache_entries < 0 || cache_entries > MAX_CE) {
    fprintf(stderr, "cache_entries '%d' can only be 0-100.\n", cache_entries);
    is_pass = false;
  }
  return is_pass;
}

/**********************************************************************************/
// Function to gracefully shutdown when pass Ctrl+C
// Terminate server gracefully
// Print the number of pending requests in the request queue
// close log file
// Remove cache (extra credit B)
void gracefullyTerminated(int sig) {
  stop = true;
  // count and free resources
  int pending_count = 0;
  pthread_mutex_lock(&queue_mutex);
  printf("Server terminating ...\n");
  for (int i = 0; i < qlen; ++i) {
    if (queue[i] != NULL) {
      free(queue[i]->request);
      free(queue[i]);
      queue[i] = NULL;
      ++pending_count;
    }
  }
  add_queue_idx = get_queue_idx = 0;
  printf("The number of pending requests in the request queue: %d\n", pending_count);
  fflush(log_file);
  fclose(log_file);
  printf("Main thread exiting.\n");
  fflush(stdout);
  deleteCache();
  pthread_mutex_unlock(&queue_mutex);
  exit(EXIT_SUCCESS);
}

/**********************************************************************************/

int main(int argc, char **argv) {
  // Error check on number of arguments
  if (argc != 8) {
    printf("usage: %s port path num_dispatcher num_workers dynamic_flag queue_length cache_size\n", argv[0]);
    return -1;
  }
  // Get the input args
  getArgs(argv);
  // Perform error checks on the input arguments
  if (!checkArgs()) {
    return EXIT_FAILURE;
  }
  if (dynamic_flag) {
    printf("Starting server on port %d: %d disp, dynamic worker\n", port, num_dispatch);
  } else {
    printf("Starting server on port %d: %d disp, %d work\n", port, num_dispatch, num_workers);
  }
  if (cache_entries > 0) {
    printf("Enable cache with size of %d\n", cache_entries);
  }
  // Change SIGINT action for grace termination
  signal(SIGINT, gracefullyTerminated);
  // Open log file
  log_file = fopen("web_server_log", "w");
  // Change the current working directory to server root directory
  chdir(root_path);
  // Initialize cache (extra credit B)
  initCache();
  // Start the server
  init(port);
  // Create dispatcher and worker threads (all threads should be detachable)
  queue = malloc(sizeof(request_t*)*qlen);
  for (int i = 0; i < qlen; ++i) {
    queue[i] = NULL;
  }
  for (int i = 0; i < num_dispatch; ++i) {
    pthread_t tid;
    pthread_create(&tid, NULL, dispatch, NULL);
  }
  if (dynamic_flag) {
    // initlaize 1 worker thread at the begining when dynamic
    pthread_t woker_t;
    int worker_tid = 0;
    pthread_create(&woker_t, NULL, worker, &worker_tid);
  } else {
    for (int i = 0; i < num_workers; ++i) {
      pthread_t woker_t;
      int worker_tid = i;
      pthread_create(&woker_t, NULL, worker, &worker_tid);
    }
  }
  // Create dynamic pool manager thread (extra credit A)
  if (dynamic_flag) {
    pthread_t dynamic_t;
    pthread_create(&dynamic_t, NULL, dynamic_pool_size_update, NULL);
  }
  // Terminate server gracefully
  // Print the number of pending requests in the request queue
  // close log file
  // Remove cache (extra credit B)
  // done in function gracefullyTerminated()
  pthread_exit(0);
}
